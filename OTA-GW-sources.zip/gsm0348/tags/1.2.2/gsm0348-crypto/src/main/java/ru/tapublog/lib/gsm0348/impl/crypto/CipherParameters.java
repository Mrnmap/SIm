package ru.tapublog.lib.gsm0348.impl.crypto;

public interface CipherParameters
{

}
