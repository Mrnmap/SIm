						SIM

The program SIM.pl is a Perl script that allows you to dump the phone
book of a GSM SIM card.

Author: Ludovic Rousseau <ludovic.rousseau@free.fr>
Download address: http://ludovic.rousseau.free.fr/softwares/SIM-x.y.tar.gz

I developped this program using GSM 11.11 specifications found on
http://www.goldfuss.de/deceed/simgsm.html
(http://www.goldfuss.de/deceed/gsm11-11.pdf)

The document is old (december 1995) but it is enough for what I wanted
to do.

The programs are distributed under the terms of the GNU General Public
License as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version. See LICENCE.txt.

