This example contains source code for implementing
an ISO7816-4 command set with BasicCard. 

Note: This is just an example and not a full tested
application. It is incomplete regarding some features
and it is not fully tested. Use on your own risk!

The sample code is following as much as possible the
command set as specified in ISO7816-4. Details also
have been taken from specification of indian transport
application (Specifications for the Smart-Card 
Operating System for Transport Applications (SCOSTA))
which can be found at http://parivahan.nic.in/

Requirements:
Profesional BasicCard ZC5.4 Rev B (or later revision)
BasicCard Development Software 4.36 (or newer version)