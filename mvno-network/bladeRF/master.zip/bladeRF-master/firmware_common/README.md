This directory contains files shared between firmware and host software.
