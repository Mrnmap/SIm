This directory contains a sample `.gdbinit` file that may be used to configure
GDB when debugging the firmware.

This file is copied to the build `output` directory alongside the firmware
image during the build.
