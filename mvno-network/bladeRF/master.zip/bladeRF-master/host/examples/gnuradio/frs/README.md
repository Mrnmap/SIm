The `bladeRF_frs.grc` flowgraph implements a full-duplex FRS transceiver with CTCSS support and the ability to
operate on any subset of the standard FRS channels. More information may be found in the paper,
[An SDR-Based FRS Transceiver](https://www.nuand.com/bladeRF-doc/examples/bladeRF_frs.html). The source of this document
may be found in the [nuand-papers](https://www.github.com/nuand/nuand-papers/) repository.

