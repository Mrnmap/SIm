simLAB
=================
<a href="#"><img src="https://github.com/kamwar/simLAB/wiki/res/images/simLAB-logo.png" align="left" hspace="0" vspace="6"></a>
**simLAB** is a pure python tool for editing and simulating SIM card. Together with simTrace HW, it allows modification of APDU exchanged between Terminal (Mobile Equipment) and SIM.

Want to learn more? Detailed information can be found in the [simLAB wiki](https://github.com/kamwar/simLAB/wiki)
